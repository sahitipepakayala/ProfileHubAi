import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  getJobMatches,
  getMyApplications,
  getMyInterviews,
  respondToInterview,
  getMyMessages,
  getJobConversation,
  sendCandidateMessage,
} from "../../api/candidateApi";
import type { Application, Interview, JobMatch, Message } from "../../types";
import Loader from "../../components/common/Loader";

type Tab = "matches" | "applications" | "interviews" | "messages";

export default function CandidateDashboard() {
  const [tab, setTab] = useState<Tab>("matches");
  const [matches, setMatches] = useState<JobMatch[]>([]);
  const [applications, setApplications] = useState<Application[]>([]);
  const [interviews, setInterviews] = useState<Interview[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [conversation, setConversation] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshingMatches, setRefreshingMatches] = useState(false);
  const [respondingId, setRespondingId] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [needsEmbedding, setNeedsEmbedding] = useState(false);

  const fetchMatches = async () => {
    try {
      const res = await getJobMatches();
      setMatches(res.matches);
      setNeedsEmbedding(false);
    } catch (err: unknown) {
      const message =
        (err as { response?: { data?: { message?: string } } })?.response?.data
          ?.message ?? "";
      if (message.toLowerCase().includes("embedding")) {
        setNeedsEmbedding(true);
        setMatches([]);
      } else {
        throw err;
      }
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setError("");
      try {
        const [appRes, interviewRes, msgRes] = await Promise.all([
          getMyApplications(),
          getMyInterviews(),
          getMyMessages().catch(() => ({ messages: [] })),
        ]);
        setApplications(appRes.applications);
        setInterviews(interviewRes.interviews);
        setMessages(msgRes.messages);
        await fetchMatches();
      } catch {
        setError("Failed to load dashboard data.");
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleRefreshMatches = async () => {
    setRefreshingMatches(true);
    setError("");
    try {
      await fetchMatches();
    } catch {
      setError("Failed to refresh job matches.");
    } finally {
      setRefreshingMatches(false);
    }
  };

  const handleInterviewResponse = async (
    interviewId: string,
    response: "confirmed" | "declined"
  ) => {
    setRespondingId(interviewId);
    setError("");
    try {
      const { interview } = await respondToInterview(interviewId, response);
      setInterviews((prev) =>
        prev.map((i) => (i._id === interviewId ? interview : i))
      );
    } catch {
      setError("Failed to respond to interview.");
    } finally {
      setRespondingId(null);
    }
  };

  const handleLoadConversation = async (jobId: string) => {
    setSelectedJobId(jobId);
    try {
      const res = await getJobConversation(jobId);
      setConversation(res.messages);
    } catch {
      setError("Failed to load messages.");
    }
  };

  const handleSendMessage = async () => {
    if (!selectedJobId || !newMessage.trim()) return;
    setSendingMessage(true);
    try {
      const res = await sendCandidateMessage(selectedJobId, newMessage.trim());
      setConversation((prev) => [...prev, res.data]);
      setNewMessage("");
    } catch {
      setError("Failed to send message.");
    } finally {
      setSendingMessage(false);
    }
  };

  const unreadCount = messages.filter((m) => m.senderRole === "company" && !m.read).length;

  if (loading) return <Loader />;

  const pendingInterviews = interviews.filter((i) => i.status === "proposed").length;
  const activeApplications = applications.filter(
    (a) => !["rejected", "hired"].includes(a.status)
  ).length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Candidate Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">
            Discover matching jobs, track applications, and manage interviews
          </p>
        </div>
        <Link
          to="/candidate/profile"
          className="bg-blue-600 text-white text-sm font-semibold px-5 py-2.5 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Update Profile
        </Link>
      </div>

      {error && (
        <div className="mb-6 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-600">
          {error}
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Job Matches", value: matches.length },
          { label: "Active Applications", value: activeApplications },
          { label: "Pending Interviews", value: pendingInterviews },
          { label: "Unread Messages", value: unreadCount },
        ].map((stat) => (
          <div
            key={stat.label}
            className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm"
          >
            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
            <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-1 mb-6 bg-gray-100 p-1 rounded-lg w-fit flex-wrap">
        {(["matches", "applications", "interviews", "messages"] as Tab[]).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 text-sm font-medium rounded-md transition-all capitalize relative ${
              tab === t
                ? "bg-white text-blue-600 shadow-sm"
                : "text-gray-500 hover:text-gray-700"
            }`}
          >
            {t}
            {t === "messages" && unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {tab === "matches" && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-semibold text-gray-900">Recommended Jobs</h2>
            <button
              onClick={handleRefreshMatches}
              disabled={refreshingMatches || needsEmbedding}
              className="text-xs px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {refreshingMatches ? "Refreshing..." : "Refresh Matches"}
            </button>
          </div>

          {needsEmbedding ? (
            <div className="px-6 py-12 text-center">
              <p className="text-sm text-gray-500 mb-2">
                Upload your resume or add skills to enable AI job matching.
              </p>
              <Link
                to="/candidate/profile"
                className="text-blue-600 text-sm font-medium hover:underline"
              >
                Go to Profile →
              </Link>
            </div>
          ) : matches.length === 0 ? (
            <div className="px-6 py-12 text-center">
              <p className="text-sm text-gray-400">No matching jobs found yet.</p>
              <p className="text-xs text-gray-400 mt-1">
                Try updating your skills or check back when more jobs are posted.
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {matches.map((job) => (
                <div key={job._id} className="px-6 py-4 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {job.extractedRoles?.length > 0
                        ? job.extractedRoles.join(", ")
                        : "Open Role"}
                    </p>
                    <p className="text-xs text-gray-500 mt-0.5">
                      {job.companyDetails?.companyName}
                      {job.companyDetails?.industry
                        ? ` · ${job.companyDetails.industry}`
                        : ""}
                    </p>
                    <p className="text-xs text-gray-400 mt-1 truncate">
                      {job.rawDescription}
                    </p>
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {job.extractedSkills?.slice(0, 4).map((skill) => (
                        <span
                          key={skill}
                          className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                      {job.extractedSkills?.length > 4 && (
                        <span className="text-xs text-gray-400">
                          +{job.extractedSkills.length - 4}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <MatchBadge score={job.matchPercentage} />
                    <Link
                      to={`/candidate/jobs/${job._id}`}
                      className="text-xs px-3 py-1.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg hover:bg-blue-100 transition-colors"
                    >
                      View Details
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {tab === "applications" && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">
              My Applications ({applications.length})
            </h2>
          </div>
          {applications.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-12">
              You haven't applied to any jobs yet.
            </p>
          ) : (
            <div className="divide-y divide-gray-100">
              {applications.map((app) => {
                const job = typeof app.job === "object" ? app.job : null;
                const company = typeof app.company === "object" ? app.company : null;
                return (
                  <div key={app._id} className="px-6 py-4 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {job?.extractedRoles?.join(", ") || "Applied Role"}
                      </p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {company?.companyName}
                        {company?.industry ? ` · ${company.industry}` : ""}
                      </p>
                      {app.matchScoreAtApply !== null && (
                        <p className="text-xs text-gray-400 mt-0.5">
                          Match at apply: {app.matchScoreAtApply}%
                        </p>
                      )}
                    </div>
                    <ApplicationStatusBadge status={app.status} />
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {tab === "interviews" && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="px-6 py-4 border-b border-gray-100">
            <h2 className="font-semibold text-gray-900">
              Interviews ({interviews.length})
            </h2>
          </div>
          {interviews.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-12">
              No interviews scheduled yet.
            </p>
          ) : (
            <div className="divide-y divide-gray-100">
              {interviews.map((interview) => {
                const job = typeof interview.job === "object" ? interview.job : null;
                const company = typeof interview.company === "object" ? interview.company : null;
                return (
                  <div key={interview._id} className="px-6 py-4">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {job?.extractedRoles?.join(", ") || "Interview"}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {company?.companyName}
                        </p>
                        <p className="text-xs text-gray-600 mt-2">
                          {new Date(interview.scheduledAt).toLocaleString()} ·{" "}
                          <span className="capitalize">{interview.mode}</span>
                        </p>
                        {interview.meetingDetails && (
                          <p className="text-xs text-blue-600 mt-1">
                            {interview.meetingDetails}
                          </p>
                        )}
                        {interview.notes && (
                          <p className="text-xs text-gray-500 mt-1 italic">
                            {interview.notes}
                          </p>
                        )}
                      </div>
                      <InterviewStatusBadge status={interview.status} />
                    </div>
                    {interview.status === "proposed" && (
                      <div className="flex gap-2 mt-3">
                        <button
                          onClick={() =>
                            handleInterviewResponse(interview._id, "confirmed")
                          }
                          disabled={respondingId === interview._id}
                          className="text-xs px-3 py-1.5 bg-green-50 text-green-700 border border-green-200 rounded-lg hover:bg-green-100 disabled:opacity-50 transition-colors"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() =>
                            handleInterviewResponse(interview._id, "declined")
                          }
                          disabled={respondingId === interview._id}
                          className="text-xs px-3 py-1.5 bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 disabled:opacity-50 transition-colors"
                        >
                          Decline
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
      {tab === "messages" && (
        <div className="flex gap-6">
          <div className="w-64 flex-shrink-0">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
              <div className="p-4 border-b border-gray-100">
                <h2 className="text-sm font-semibold text-gray-900">Messages</h2>
              </div>
              {messages.length === 0 ? (
                <p className="text-xs text-gray-400 text-center py-8 px-4">
                  No messages yet. Companies will send invitations and messages here.
                </p>
              ) : (
                <div className="divide-y divide-gray-100">
                  {Array.from(new Set(messages.map((m) => {
                    const j = typeof m.job === "object" ? m.job._id : m.job;
                    return j;
                  }))).map((jobId) => {
                    const msg = messages.find((m) => {
                      const j = typeof m.job === "object" ? m.job._id : m.job;
                      return j === jobId;
                    });
                    const job = msg && typeof msg.job === "object" ? msg.job : null;
                    const company = msg && typeof msg.company === "object" ? msg.company : null;
                    const hasUnread = messages.some(
                      (m) => (typeof m.job === "object" ? m.job._id : m.job) === jobId &&
                        m.senderRole === "company" && !m.read
                    );
                    return (
                      <button
                        key={jobId}
                        onClick={() => handleLoadConversation(jobId)}
                        className={`w-full text-left px-4 py-3 hover:bg-gray-50 transition-colors ${
                          selectedJobId === jobId ? "bg-blue-50 border-l-2 border-blue-600" : ""
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {job?.extractedRoles?.join(", ") || "Job"}
                          </p>
                          {hasUnread && (
                            <span className="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0" />
                          )}
                        </div>
                        <p className="text-xs text-gray-500">{company?.companyName}</p>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
          <div className="flex-1 bg-white rounded-xl border border-gray-200 shadow-sm flex flex-col">
            {!selectedJobId ? (
              <div className="flex-1 flex items-center justify-center p-12">
                <p className="text-sm text-gray-400">Select a conversation to view messages</p>
              </div>
            ) : (
              <>
                <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-96">
                  {conversation.map((msg) => (
                    <div
                      key={msg._id}
                      className={`flex ${msg.senderRole === "candidate" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-xs px-3 py-2 rounded-xl text-sm ${
                          msg.senderRole === "candidate"
                            ? "bg-blue-600 text-white"
                            : "bg-gray-100 text-gray-800"
                        } ${msg.type === "invitation" ? "border-2 border-green-300" : ""}`}
                      >
                        {msg.type === "invitation" && (
                          <p className="text-xs font-semibold mb-1 text-green-700">Interview Invitation</p>
                        )}
                        <p className="whitespace-pre-wrap">{msg.content}</p>
                        <p className={`text-xs mt-1 ${msg.senderRole === "candidate" ? "text-blue-200" : "text-gray-400"}`}>
                          {new Date(msg.createdAt).toLocaleString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-4 border-t border-gray-100 flex gap-2">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
                    placeholder="Reply to company..."
                    className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={handleSendMessage}
                    disabled={sendingMessage || !newMessage.trim()}
                    className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    Send
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function MatchBadge({ score }: { score: number }) {
  const color =
    score >= 80
      ? "bg-green-50 text-green-700"
      : score >= 60
        ? "bg-amber-50 text-amber-700"
        : "bg-red-50 text-red-600";
  return (
    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${color}`}>
      {score}%
    </span>
  );
}

function ApplicationStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    applied: "bg-gray-100 text-gray-600",
    shortlisted: "bg-blue-50 text-blue-700",
    interview: "bg-purple-50 text-purple-700",
    rejected: "bg-red-50 text-red-600",
    hired: "bg-green-50 text-green-700",
  };
  return (
    <span
      className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize flex-shrink-0 ${
        colors[status] ?? "bg-gray-100 text-gray-600"
      }`}
    >
      {status}
    </span>
  );
}

function InterviewStatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    proposed: "bg-amber-50 text-amber-700",
    confirmed: "bg-green-50 text-green-700",
    declined: "bg-red-50 text-red-600",
    completed: "bg-blue-50 text-blue-700",
    cancelled: "bg-gray-100 text-gray-600",
  };
  return (
    <span
      className={`text-xs px-2 py-0.5 rounded-full font-medium capitalize flex-shrink-0 ${
        colors[status] ?? "bg-gray-100 text-gray-600"
      }`}
    >
      {status}
    </span>
  );
}
